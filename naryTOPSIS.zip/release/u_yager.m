function mu=u_Yager(a,b,w)

mu=min([1,(a^w+b^w)^(1/w)]);
